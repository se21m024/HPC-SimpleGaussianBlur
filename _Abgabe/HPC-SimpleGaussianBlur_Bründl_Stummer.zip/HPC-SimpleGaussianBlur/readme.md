Students:<br>
Thomas Bründl<br>
Thomas Stummer<br><br>

The source code can be found in the following files:<br>
.\SimpleGaussianBlur\Program.cs<br>
.\SimpleGaussianBlur\GaussianOpenCl.cs<br>
.\SimpleGaussianBlur\blurKernel.cl<br>

The compiled executable can be found here:<br>
.\SimpleGaussianBlur\bin\Debug\SimpleGaussianBlur.exe<br><br>

When exectuing this executable, the input image "InputImage.bmp" in the same directory as the .exe File is read and the blury output image "OutputImage.bmp" is created (also in the same directory).
